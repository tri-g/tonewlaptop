import React, {useEffect,useState} from 'react'
import {Col, Container, Row} from "react-bootstrap";
import {Link} from "react-router-dom";

function Report() {
  return (
    <main className={'class1'}>
     <h1>This is Report</h1>
    </main>
  )
}

export default Report
