import React, {useEffect,useState} from 'react'
import {Col, Container, Row} from "react-bootstrap";
import {Link} from "react-router-dom";

function Add_organization() {
  return (
    <main className={'class1'}>
     <h1>This is Add Organization</h1>
    </main>
  )
}

export default Add_organization
