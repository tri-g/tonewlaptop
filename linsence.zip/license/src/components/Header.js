import React from 'react'
import {Accordion, Button, Container, Form,Navbar,Nav,NavDropdown} from "react-bootstrap";
import {Link, useRouteMatch, withRouter} from "react-router-dom";

function Header() {



  const closeNav = () => {
    document.getElementById("sidenav-wrap").className = "";
  }


  return (

    <header className="shadow">
        <div>
     <Link to="/">Dashboard</Link>
     &nbsp;&nbsp;&nbsp;&nbsp;
     <Link to="/report">Report</Link>
       &nbsp;&nbsp;&nbsp;&nbsp;
     <Link to="/manage/">Manage</Link>
      &nbsp;&nbsp;&nbsp;&nbsp;
     <Link to="/generation/">License Generation</Link>



      </div>
    </header>
  );

}

export default Header;
